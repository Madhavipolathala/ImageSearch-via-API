const accessKey = '44350019-617ae412696acfa85bb423e41'; // Replace with your actual Pixabay API key

const formEl = document.querySelector('form');
const inputEl = document.getElementById('search-input');
const searchResults = document.querySelector(".search-results");
const showMore = document.getElementById('show-more');

let inputData = "";
let page = 1;

async function searchImages() { // Corrected function name for consistency
  inputData = inputEl.value;
  const url = `https://pixabay.com/api/?key=${accessKey}&q=${inputData}&page=${page}&image_type=photo`;

  try {
    const response = await fetch(url);
    const data = await response.json();

    if (response.ok) { // Check for successful API request
      const results = data.hits; // Pixabay uses 'hits' instead of 'results'

      if (page === 1) { // Use strict equality check
        searchResults.innerHTML = "";
      }

      results.map((result) => {
        const imageWrapper = document.createElement('div');
        imageWrapper.classList.add('search-result');

        const image = document.createElement('img');
        image.src = result.previewURL; // Use previewURL for image source
        image.alt = result.tags; // You might want to customize alt text

        const imageLink = document.createElement('a');
        imageLink.href = result.pageURL;
        imageLink.target = '_blank';
        imageLink.textContent = result.tags; // You might want to customize link text

        // Append elements to the wrapper
        imageWrapper.appendChild(image);
        imageWrapper.appendChild(imageLink);

        // Append wrapper to the search results container
        searchResults.appendChild(imageWrapper);
      });
    } else {
      console.error("API request failed:", response.statusText);
      // Handle errors gracefully (e.g., display an error message)
    }
  } catch (error) {
    console.error("Error fetching images:", error);
    
  }

  page++;
  if (page > 1) {
    showMore.style.display = "block";
  }
}

let div1 = document.getElementById('div1');
formEl.addEventListener('submit', (event) => {
  event.preventDefault();
  page = 1;
// div1.a.style.display='none';
  searchImages();
});

showMore.addEventListener('click', (event) => {
  event.preventDefault();
//   div1.style.display='none';
// page+=1;
  searchImages();
});
